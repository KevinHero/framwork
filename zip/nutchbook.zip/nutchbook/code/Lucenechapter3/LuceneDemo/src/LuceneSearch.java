
public class LuceneSearch {

}
