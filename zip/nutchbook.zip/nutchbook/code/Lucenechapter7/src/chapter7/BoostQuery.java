package chapter7;


import java.io.IOException;
import java.util.Date;

import org.apache.lucene.index.Term;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

import org.apache.lucene.search.Query;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.queryParser.*;
import org.apache.lucene.search.*;


import org.apache.lucene.search.BooleanQuery;

import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.RAMDirectory;

import org.apache.lucene.search.DefaultSimilarity;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.search.payloads.BoostingTermQuery;

public class BoostQuery {

	private static final String[] ContentList = { "good Lucene cd ", 
           "good cd ,good book", 
           "good book",
           "Lucene book good" };
	
	private static final String F = "f";
	private static final String Term1 = "Lucene";
	private static final String Term2 = "good";
	private static Directory directory;
	private static Analyzer analyzer;
	
	public static void main(String[] args) throws IOException{
		directory = new RAMDirectory();
		CreateIndex();
		searchIndex();
	}

private static void CreateIndex() throws IOException{
	
	analyzer = new StandardAnalyzer();
	
	IndexWriter writer = new IndexWriter( directory, analyzer );
	for( String content : ContentList ){
		Document doc = new Document();
		Field f = new Field( F, content, Field.Store.YES, Field.Index.TOKENIZED );
		f.setOmitNorms( true );
		doc.add( f );
		writer.addDocument( doc );
	}
	writer.close();
	}

private static void searchIndex() throws IOException{
	
	IndexSearcher searcher = new IndexSearcher( directory );
	searcher.setSimilarity( new PayloadSimilarity() );
	BooleanQuery query = new BooleanQuery();
	
	Query termqery1 = new TermQuery( new Term( F, Term1 ) );
	Query termqery2 = new TermQuery( new Term( F, Term2 ) );
	query.add( termqery1, BooleanClause.Occur.SHOULD );
	query.add( termqery2, BooleanClause.Occur.SHOULD );
/*
	Query btermqery1 = new BoostingTermQuery( new Term( F, Term1 ) );
	Query btermqery2 = new BoostingTermQuery( new Term( F, Term2 ) );
	query.add( btermqery1, BooleanClause.Occur.SHOULD );
	query.add( btermqery2, BooleanClause.Occur.SHOULD );
*/
	Hits hits = searcher.search( query );
	for( int i = 0; i < hits.length(); i++ ){
			Document doc = hits.doc( i );
			int id = hits.id( i );
			float score = hits.score( i );
			System.out.println( score + " : " + doc.get( F ) );
			//Explanation exp = searcher.explain( query, id );
			//System.out.println( exp.toString() );
			}
	searcher.close();
	}

static class PayloadSimilarity extends DefaultSimilarity
{
	private static final String POS_NAME = "good";
	public float scorePayload(byte[] payload, int offset, int length){
		return isName( payload, offset, length ) ? 2.0f : 1.0f;
	}
	private static boolean isName( byte[] payload, int offset, int length ){
		String paystr = new String( payload, offset, length );
		return paystr.indexOf( POS_NAME ) >= 0 ? true : false;
		}
	}
public float lengthNorm(String fieldName, int numTerms) {
    return 1;
  }

  public float queryNorm(float sumOfSquaredWeights) {
    return 1;
  }

  public float sloppyFreq(int distance) {
    return 1;
  }

  public float coord(int overlap, int maxOverlap) {
    return 1;
  }

  public float idf(int docFreq, int numDocs) {
    return 1;
  }

  public float tf(float freq) {
    return 1;
  }

}



