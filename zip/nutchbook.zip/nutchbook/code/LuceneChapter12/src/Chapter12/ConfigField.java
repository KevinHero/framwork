package Chapter12;


public class ConfigField {

    private String fieldName;			// ������
    private String fieldValue;			// ���ֵ
    private String fieldDesc;			// ������

    public ConfigField( String fieldname, String fieldvalue, String fielddesc ) {
        this.fieldName  = fieldname;
        this.fieldValue = fieldvalue;
        this.fieldDesc  = fielddesc;
    }

    public String getDesc() {
        return fieldDesc;
    }

    public String getName() {
        return fieldName;
    }

    public String getValue() {
        return fieldValue;
    }
}