package Chapter12;

import java.sql.*;
import Configuration;

public class datatool {
	private Connection connection;
	private Statement statment;
	Configuration config = new Configuration();
	
	String driver  = config.getItemValue("MSSQL", "driver");
	String address = config.getItemValue("MSSQL", "address");
	String user    = config.getItemValue("MSSQL", "user");
	String passwd  = config.getItemValue("MSSQL", "passwd");
	public static void main(String[] args) {
		datatool tool = new datatool("BookData");
		tool.closedatatool();
	}	
		public ResultSet searchByField(String table,String name, String value) {
		ResultSet rs=null;
		String sql="select * from "+table+" where ("+name+" like '%"+value+"%')";
		System.out.println(sql);
		try {
			rs = statment.executeQuery(sql);
		} catch (SQLException e) {
			System.out.println("datatool��searchByColumn!");
			e.printStackTrace();
			}
		return rs;
	}
	public ResultSet searchresult(String sql){
		ResultSet rs=null;
		try {
			rs=statment.executeQuery(sql);
		} catch (SQLException e) {
			System.out.println("datatool����ѯ����");
			e.printStackTrace();
		}
		return rs;
}

	public boolean closedatatool() {
		try {
			statment.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("���󣺹ر����ݿ�����ʧ�ܣ�");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public String countItem(String tableName){
		String result=null;
		String sql="SELECT COUNT(*) FROM "+tableName;
		try {
			ResultSet rs=statment.executeQuery(sql);
			if(rs.next()){
			result=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
