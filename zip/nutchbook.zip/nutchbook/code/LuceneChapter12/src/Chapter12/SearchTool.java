package Chapter12;


import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.*;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.ParseException;

import org.apache.lucene.index.*;
import java.io.*;
import java.util.*;

public class SearchTool {
	private static String Dest_Index_Path = "D:\\workshop\\alldata3";
	private boolean SearchFinish = false; 
	private int result_num = 0;
	
	ConfigManager conf = new ConfigManager();
	
	/*========================================================
	 * ������������������Ϣ
	 *========================================================*/
	public static void main(String[] args) {
		
		SearchTool tool = new SearchTool();
		File indexpath = new File(Dest_Index_Path);
		
		try {
			ArrayList list = tool.BasicSearch("2","science",10,1);
			System.out.println(" Index searcher " + list.size() + "  docs");			
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	public int getResultNum() {
		return result_num;
	}
	public void setResultNum(int num) {
		result_num = num;
	}
	
	public int GetIndexNum() {
		IndexReader reader = null;
		try {
			reader = IndexReader.open(Dest_Index_Path);
		} catch (CorruptIndexException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reader.numDocs();
	}
	
	public String HighLightWords(String HighLightContent, String[] KeyWords) {
		String HighLightTitle = "";
		for (int i = 0; i < KeyWords.length; i++) {
			HighLightTitle = HighLightContent.replaceAll(KeyWords[i],
					"<font color=#C60A00>" + KeyWords[i] + "</font>");
		}
		return HighLightTitle;
	}
	public String HighLightWords(String searchType, String HighLightContent,
			String[] KeyWords) {
		String HighLightDescription = null;
		String[] ContentSplit = null;
		for (int i = 0; i < KeyWords.length; i++) {
			int pos = HighLightContent.indexOf(KeyWords[i]);
			int start = pos - 120 / (KeyWords.length + 1);
			if (start < 0)
				start = 1;
			int end = pos + 120 / (KeyWords.length + 1);
			if (end > HighLightContent.length())
				end = HighLightContent.length();
			HighLightDescription = HighLightDescription
					+ HighLightContent.substring(start, end) + "...";
		}
		for (int i = 0; i < KeyWords.length; i++) {
			HighLightDescription = HighLightDescription.replaceAll(KeyWords[i],
					"<font color=#C60A00>" + KeyWords[i] + "</font>");
		}
		HighLightDescription = HighLightDescription.replaceAll("null", "");
		return HighLightDescription;
	}

	public ArrayList BasicSearch(String searchType, String keyWord,
			int pageSize, int CurrentPage) throws ParseException {
		
		if (CurrentPage > 50)
			CurrentPage = 50;
		if (CurrentPage < 1)
			CurrentPage = 1;
		
		ArrayList<SearchResultBean> SearchResult = new ArrayList<SearchResultBean>();
		boolean HasBeenSearched = false;
		StandardAnalyzer analyzer = new StandardAnalyzer();
		
		while (!SearchFinish) {
			try {
				String searchField = "";
				if (searchType.equalsIgnoreCase("1"))
					searchField = "filetype";
				if (searchType.equalsIgnoreCase("2"))
					searchField = "contents";
				BooleanQuery query = new BooleanQuery();
				String[] KeyWords = keyWord.split(" ");
				IndexSearcher searcher = new IndexSearcher( Dest_Index_Path );

				String keyword = new String();
				for (int i = 0; i < KeyWords.length; i++) {// ������ѯ����
					TermQuery q = new TermQuery(new Term(searchField,KeyWords[i]));
					query.add(q, BooleanClause.Occur.MUST);
					keyword = keyword + KeyWords[i] + " ";
				}
				Hits hits =null;
				hits= searcher.search(query);
				
				this.setResultNum(hits.length());
				if (hits.length() == 0 && HasBeenSearched == false) { // ���û�в鵽��Ϣ
					// keyWord = analyzer.segment(keyWord, " ");      // �ִ�

					HasBeenSearched = true;
				} else {
					SearchFinish = true;
					if (CurrentPage > this.getResultNum() / pageSize)
						CurrentPage = this.getResultNum() / pageSize;

					if (CurrentPage == 0 && this.getResultNum() >= 0) {
						CurrentPage = 1;
						pageSize = this.getResultNum();
					}
					for (int i = (CurrentPage - 1) * pageSize; i < CurrentPage * pageSize; i++) {
						SearchResultBean searchResultBean = new SearchResultBean();
						SearchResult.add( searchResultBean );
						searchResultBean = null;						
					}
				}

				hits=null;
				System.gc();
			} catch (CorruptIndexException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		return SearchResult;
	}
}