package Chapter12;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.io.*;
import java.sql.*;
import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

import org.apache.lucene.index.IndexWriter;
import java.util.Vector;
import org.apache.lucene.analysis.*;

public class databaseTool {
	
	private String strdriver;
	private String connstring;

	private Connection connection;
	private Statement statement;
	ConfigManager config = new ConfigManager();
	
	String driver   = config.getItemValue("MSSQL", "driver");
	String address  = config.getItemValue("MSSQL", "address");
	String username = config.getItemValue("MSSQL", "user");
	String passwd   = config.getItemValue("MSSQL", "passwd");
	
	public databaseTool()
	{
		strdriver = "com.microsoft.jdbc.sqlserver.SQLServerDriver";  
		connstring = address;
		String user = username;   
		String password = passwd; 
		try {
			Class.forName(strdriver).newInstance();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} try {
			connection = DriverManager.getConnection(connstring, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} try {
			statement = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public databaseTool(String strconnect) {
		strdriver = driver;  
		connstring = address;
		String user = username;
		String password = passwd;
		
		try {
			Class.forName(strdriver).newInstance();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} try {
			connection = DriverManager.getConnection(connstring, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} try {
			statement = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		databaseTool tool = new databaseTool("BookData");
		tool.closedatatool();
	}	

	public ResultSet searchByField(String table,String name, String value) {
		ResultSet rs=null;
		String sql="select * from "+table+" where ("+name+" like '%"+value+"%')";
		System.out.println(sql);
		try {
			rs = statement.executeQuery(sql);
		} catch (SQLException e) {
			System.out.println("databaseTool��searchByColumn!");
			e.printStackTrace();
			}
		return rs;
	}
	public ResultSet searchresult(String sql){
		ResultSet rs=null;
		try {
			rs=statement.executeQuery(sql);
		} catch (SQLException e) {
			System.out.println("databaseTool����ѯ����");
			e.printStackTrace();
		}
		return rs;
}

	public boolean closedatatool() {
		try {
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("databaseTool���ر����ݿ�ʧ��");
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public String countItem(String tableName){
		String result=null;
		String sql="SELECT COUNT(*) FROM "+tableName;
		try {
			ResultSet rs=statement.executeQuery(sql);
			if(rs.next()){
			result=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public int  IndexCreate(String indexpath) throws IOException
	{
		int num = 0;
		try{
			IndexWriter FSWriter = new IndexWriter(indexpath,new StandardAnalyzer(),false);
			FSWriter.setUseCompoundFile(true);
		
			num = FSWriter.docCount();
			
			IndexCreate(FSWriter);
			FSWriter.optimize();
			FSWriter.close();
		} catch (IOException e){
			e.printStackTrace();
		}
		
		return num;
	}
	
	public boolean  IndexCreate(IndexWriter fswriter) throws IOException {

		Connection conn = null;
		ConfigManager config = new ConfigManager();
		String driver = config.getItemValue("MSSQL", "driver");
		String address = config.getItemValue("MSSQL", "address");
		String username = config.getItemValue("MSSQL", "user");
		String passwd = config.getItemValue("MSSQL", "passwd");
		config=null;
		try {
			Class.forName(driver).newInstance();
		} catch (InstantiationException e2) {
			e2.printStackTrace();
		} catch (IllegalAccessException e2) {
			e2.printStackTrace();
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}
		String url = address;
		String user = username;
		String password = passwd;
		Statement stmt = null;
		Statement stmt1 = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		int countNum=0;
		int countMin =0;
		int tempcount=0;
		try {
			conn = DriverManager.getConnection(url, user, password);
			stmt =  conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			stmt1 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			stmt3 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			stmt4 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		
		ResultSet rsCount =null;
		try {
			String countSql = "select max(id),min(id) from Lucene_content";
			rsCount = stmt.executeQuery(countSql);
			while(rsCount.next()){
			countNum = rsCount.getInt(1);
			countMin = rsCount.getInt(2);
			
			}
			System.out.println("countNum="+countNum);
			System.out.println("countMin="+countMin);
		} catch (SQLException e2) {
			e2.printStackTrace();
		}finally{
			if(stmt!=null){
				try {
					stmt.close();
					stmt = null;
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		ResultSet rs = null;
		long time = System.currentTimeMillis();
		String sql = null;
		int rs_num = 0;
		int value = 1000;
		int MergeFactorValue = 200;
		IndexWriter writer = null;
		FileManager manager = new FileManager();
		Vector v = manager.getFile(); 
		String temp =(String)v.get(0);
		int infoCount= Integer.parseInt(temp);
		if(countNum<=infoCount){
			return false;      // �쳣�˳�
		}

		sql = "select * from Lucene_content where id  between "  + countMin + " and " + countNum + " " ;
		try {
			rs = stmt1.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;      // �쳣�˳�
			
		}	
		Directory ramdirectory = new RAMDirectory();
		Analyzer TextAnalyzer = new StandardAnalyzer();            // ���ɷ�����
		IndexWriter RAMWriter = new IndexWriter(ramdirectory ,TextAnalyzer ,true); // ����������
		
		try{
			while (rs.next()) 
			{
				rs_num ++;
				try {
					
					String id = rs.getString("id");
					if (id == null || id.equalsIgnoreCase(""))
						id = " " ;
					Field field_id = new Field("id", id,   
							Field.Store.YES,Field.Index.UN_TOKENIZED);
					
					String title = rs.getString("title");
					if (title == null || title.equalsIgnoreCase(""))
						title = " ";
					Field field_title = new Field("title", title,   
							Field.Store.YES,Field.Index.TOKENIZED);
					
					String contents = rs.getString("contents");
					if (contents == null || contents.equalsIgnoreCase(""))
						contents = " ";	
					Field field_contents = new Field("contents", contents,   
							Field.Store.YES,Field.Index.TOKENIZED);
	
					Field field_type = new Field("type", "dataBase" ,   
							Field.Store.YES,Field.Index.UN_TOKENIZED);
														
					Document document = new Document() ; 
					document.add(field_id);
					document.add(field_title);
					document.add(field_contents);
					document.add(field_type);
					
					RAMWriter.addDocument(document);
				
					
				}catch (SQLException e) {
					continue;  // ������ǰ��
				}
				
			}
			RAMWriter.optimize();
			RAMWriter.close();
			fswriter.addIndexes(new Directory[]{ramdirectory});
			
		}catch (SQLException e) {
			;  
		}

		return true;				
	}
	

}
