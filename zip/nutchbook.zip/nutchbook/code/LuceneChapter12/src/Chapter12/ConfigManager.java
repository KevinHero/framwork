package Chapter12;

import java.io.*;
import java.util.*;

import org.jdom.*;
import org.jdom.input.SAXBuilder;
import org.jdom.output.*;

public class ConfigManager {

    private static Object synObj = new Object(); // ͬ������

    private static String  relativePath  = "BNVConfig.xml"; // �����ļ�����ļ���
    private static String  absolutePath  = "";            // �����ļ�����·��
    private static Element elemConfRoot  = null;            // �����ļ��еĸ�Ԫ��

    private static HashMap mapConfType   = new HashMap();   // ������������ӳ�������
    private static HashMap mapConfItem   = new HashMap();   // ���е�������ӳ�������

    private static XMLOutputter xmlWriter = new XMLOutputter(Format.getPrettyFormat());

    /* ���ù����๹�캯������ȡ�����ļ������������ڴ滺������*/
    public ConfigManager() {
    	
        synchronized (synObj) {
            if (elemConfRoot == null) {  //�������ļ��ж�ȡ������Ϣ��ֻ��ȡһ��
                try {
                    SAXBuilder builder = new SAXBuilder();
                    Document   doc = builder.build(ConfigManager.class.getResourceAsStream(relativePath));
                    elemConfRoot = doc.getRootElement();
                    //��ȡ���÷���
                    List listConfigType = elemConfRoot.getChildren();
                    for (int i = 0; i < listConfigType.size(); i++) {
                        Element elemConfigType = (Element) listConfigType.get(i);
                        String typeName = elemConfigType
                                .getAttributeValue("name");
                        //��ȡ���÷����е�������
                        List listItems = elemConfigType.getChildren();
                        for (int j = 0; j < listItems.size(); j++) {
                            Element elemItem = (Element) listItems.get(j);
                            String itemName = elemItem
                                    .getAttributeValue("name");
                            mapConfItem.put(typeName + "&" + itemName, null);
                        }
                        mapConfType.put(typeName, null);
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public boolean addConfigType(String name, String description) {
        synchronized (synObj) {
            if (mapConfType.containsKey(name))
                return false;
            elemConfRoot.addContent(configTypeToElement(name, description));
            try {
                //������ĵ������ļ�
                xmlWriter.output(elemConfRoot, new FileOutputStream( absolutePath));
            } catch (Exception e) {
                return false;
            }
            mapConfType.put(name, null);
        }
        return true;
    }

    private Element getElementByNameAttr(Element father, String nameAttr) {
        List listChildren = father.getChildren();
        for (Iterator iter = listChildren.iterator(); iter.hasNext();) {
            Element element = (Element) iter.next();
            if (element.getAttributeValue("name").equals(nameAttr))
                return element;
        }
        return null;
    }

    private Element configTypeToElement(String name, String description) {
        Element e = new Element("ConfigClassify");
        e.setAttribute("name", name);
        e.setAttribute("description", description);
        return e;
    }

    private Element configItemToElement(String name, String value,
            String description) {
        Element e = new Element("Field");
        e.setAttribute("name", name);
        e.setAttribute("value", value);
        e.setAttribute("description", description);
        return e;
    }

    public boolean updateConfigType(String oldName, String newName,
            String newDescription) {
        synchronized (synObj) {
            //������oldName�ķ��࣬����false
            if (mapConfType.containsKey(oldName) == false)
                return false;

            if (oldName.equals(newName) == false) {

                mapConfType.remove(oldName);
                mapConfType.put(newName, null);

                Vector vecKeys = new Vector();
                for (Iterator iter = mapConfItem.keySet().iterator(); iter
                        .hasNext();) {
                    String key = (String) iter.next();
                    if (key.startsWith(oldName + "&"))
                    	vecKeys.add(new String(key));
                }
                for (Iterator iter = vecKeys.iterator(); iter.hasNext();) {
                    String key = (String) iter.next();
                    String newKey = newName + key.substring(key.indexOf("&"));
                    mapConfItem.remove(key);
                    mapConfItem.put(newKey, null);

                }
            }

            //����elemConfRoot�е����÷���
            Element elemConfigType = getElementByNameAttr(elemConfRoot,
                    oldName);
            elemConfigType.setAttribute("name", newName);
            elemConfigType.setAttribute("description", newDescription);
            try {
                //������ĵ������ļ�
            	xmlWriter.output(elemConfRoot, new FileOutputStream(
                		relativePath));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    public boolean delConfigType(String name) {
        synchronized (synObj) {
            if (mapConfType.containsKey(name) == false)
                return false;
            Vector vecKeys = new Vector();
            for (Iterator iter = mapConfItem.keySet().iterator(); iter
                    .hasNext();) {
                String key = (String) iter.next();
                if (key.startsWith(name + "&"))
                	vecKeys.add(new String(key));
            }
            for (Iterator iter = vecKeys.iterator(); iter.hasNext();) {
                String key = (String) iter.next();
                mapConfItem.remove(key);
            }

            Element elemConfigType = getElementByNameAttr(elemConfRoot,
                    name);
            elemConfRoot.removeContent(elemConfigType);
            try {
                //������ĵ������ļ�
            	xmlWriter.output(elemConfRoot, new FileOutputStream(
            			relativePath));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    public boolean addItem(String configTypeName, String itemName,
            String itemValue, String itemDescription) {
        synchronized (synObj) {
            //������÷��಻���ڻ��߸��������Ѿ����ڣ�����false
            if (mapConfType.containsKey(configTypeName) == false
                    || mapConfItem.containsKey(configTypeName + "&"
                            + itemName))
                return false;
            //��mapConfItem�����Ӽ�¼
            mapConfItem.put(configTypeName + "&" + itemName, null);

            //����XML��Element
            Element elemConfigType = getElementByNameAttr(elemConfRoot,
                    configTypeName);
            elemConfigType.addContent(configItemToElement(itemName, itemValue,
                    itemDescription));
            try {
                //������ĵ������ļ�
            	xmlWriter.output(elemConfRoot, new FileOutputStream(
            			relativePath));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    public boolean updateItem(String configTypeName, String itemName,
            String itemValue, String itemDescription) {
        synchronized (synObj) {
            //������÷��಻���ڻ��߸���������ڣ�����false
            if (mapConfType.containsKey(configTypeName) == false
                    || mapConfItem.containsKey(configTypeName + "&"
                            + itemName) == false)
                return false;

            //����XML��Element
            Element elemConfigType = getElementByNameAttr(elemConfRoot,
                    configTypeName);
            Element elemConfigItem = getElementByNameAttr(elemConfigType,
                    itemName);
            elemConfigType.removeContent(elemConfigItem);
            elemConfigType.addContent(configItemToElement(itemName, itemValue,
                    itemDescription));
            try {
                //������ĵ������ļ�
            	xmlWriter.output(elemConfRoot, new FileOutputStream(
            			relativePath));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    public boolean delItem(String configTypeName, String itemName) {
        synchronized (synObj) {
            //������÷��಻���ڻ��߸���������ڣ�����false
            if (mapConfType.containsKey(configTypeName) == false
                    || mapConfItem.containsKey(configTypeName + "&"
                            + itemName) == false)
                return false;

            //����XML��Element
            Element elemConfigType = getElementByNameAttr(elemConfRoot,
                    configTypeName);
            Element elemConfigItem = getElementByNameAttr(elemConfigType,
                    itemName);
            elemConfigType.removeContent(elemConfigItem);
            try {
                //������ĵ������ļ�
                xmlWriter.output(elemConfRoot, new FileOutputStream(absolutePath));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    public String getItemValue(String configTypeName, String itemName) {
        synchronized (synObj) {
            //�������������ڣ�����false
            if (mapConfItem.containsKey(configTypeName + "&" + itemName)) {
                Element elemConfigType = getElementByNameAttr(
                        elemConfRoot, configTypeName);
                Element elemConfigItem = getElementByNameAttr(elemConfigType,
                        itemName);
                return elemConfigItem.getAttributeValue("value");
            }
        }
        return null;
    }

    public Vector getConfigTypes() {
        Vector vConfigType = new Vector();
        synchronized (synObj) {
            List listConfigType = elemConfRoot.getChildren();
            for (Iterator iter = listConfigType.iterator(); iter.hasNext();) {
                Element element = (Element) iter.next();
                String name = element.getAttributeValue("name");
                String desc = element.getAttributeValue("description");
                vConfigType.add(new ConfigClassify(name, desc));
            }
        }
        return vConfigType;
    }

    public Vector getConfigItems(String configTypeName) {
        Vector vConfigItem = new Vector();
        synchronized (synObj) {
            Element elemConfigType = getElementByNameAttr(elemConfRoot,
                    configTypeName);
            if (elemConfigType != null) {
                List listConfigItem = elemConfigType.getChildren();
                for (Iterator iter = listConfigItem.iterator(); iter.hasNext();) {
                    Element element = (Element) iter.next();
                    String name = element.getAttributeValue("name");
                    String value = element.getAttributeValue("value");
                    String desc = element.getAttributeValue("description");
                    vConfigItem.add(new ConfigField(name, value, desc));
                }
            }
        }
        return vConfigItem;
    }

    public static void main(String[] args) {
        ConfigManager config = new ConfigManager();
        System.out.println(config.getItemValue("MSSQL","driver"));
        System.out.println(config.getItemValue("MSSQL","address"));
        System.out.println(config.getItemValue("MSSQL","user"));
        System.out.println(config.getItemValue("MSSQL","passwd")); 
    }
}