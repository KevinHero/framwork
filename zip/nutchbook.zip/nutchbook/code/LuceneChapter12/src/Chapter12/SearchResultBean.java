package Chapter12;

public class SearchResultBean {

}
