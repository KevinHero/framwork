package Chapter12;

import java.io.*;
import java.util.*;

import org.jdom.*;
import org.jdom.input.SAXBuilder;
import org.jdom.output.*;


public class Configuration {

     /* Ϊ�����ļ����·�� */
    private static String relativeMosticConfigUrl = "MosticConfig.xml";

    /*Ϊ�����ļ�����·��  */
    private static String MosticConfigUrl = null;

    /*��Ӧ�����ļ��еĸ�Ԫ�� */
    private static Element elemConfiguration = null;

    /**�������е����÷���   */
    private static HashMap mapConfigType = new HashMap();

    /*�������е������� */
    private static HashMap mapConfigItem = new HashMap();

    /*����ͬ�� */
    private static Object synchronizeObj = new Object();

    private static XMLOutputter outputter = new XMLOutputter(Format
            .getPrettyFormat());

    /*���ù����๹�캯�����������ļ��ж�ȡ������Ϣ�����������ڴ�Ļ�������*/
    public Configuration() {
        synchronized (synchronizeObj) {
            //�������ļ��ж�ȡ������Ϣ��ֻ��ȡһ��
            if (elemConfiguration == null) {
                try {
                    SAXBuilder builder = new SAXBuilder();
                    Document doc = builder.build(Configuration.class
                            .getResourceAsStream(relativeMosticConfigUrl));
                    elemConfiguration = doc.getRootElement();
                    //��ȡ���÷���
                    List listConfigType = elemConfiguration.getChildren();
                    for (int i = 0; i < listConfigType.size(); i++) {
                        Element elemConfigType = (Element) listConfigType
                                .get(i);
                        String typeName = elemConfigType
                                .getAttributeValue("name");
                        //��ȡ���÷����е�������
                        List listItems = elemConfigType.getChildren();
                        for (int j = 0; j < listItems.size(); j++) {
                            Element elemItem = (Element) listItems.get(j);
                            String itemName = elemItem
                                    .getAttributeValue("name");
                            mapConfigItem.put(typeName + "&" + itemName, null);
                        }
                        mapConfigType.put(typeName, null);
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    /**
     * �����µ����÷���: ���÷�������\���÷�������
     * @return trueΪ�����ɹ���falseʧ�ܣ�ԭ������Ǵ���ͬ������
     */
    public boolean addConfigType(String name, String description) {
        synchronized (synchronizeObj) {
            if (mapConfigType.containsKey(name))
                return false;
            elemConfiguration.addContent(configTypeToElement(name, description));
            try {
                //������ĵ������ļ�
                outputter.output(elemConfiguration, new FileOutputStream(
                		MosticConfigUrl));
            } catch (Exception e) {
                return false;
            }
            mapConfigType.put(name, null);
        }
        return true;
    }

    /*����name���Ի�ȡ��Ӧ��Element
     * @return ������Ӧ����Element
     */
    private Element getElementByNameAttr(Element father, String nameAttr) {
        List listChildren = father.getChildren();
        for (Iterator iter = listChildren.iterator(); iter.hasNext();) {
            Element element = (Element) iter.next();
            if (element.getAttributeValue("name").equals(nameAttr))
                return element;
        }
        return null;
    }

    private Element configTypeToElement(String name, String description) {
        Element e = new Element("ConfigType");
        e.setAttribute("name", name);
        e.setAttribute("description", description);
        return e;
    }

    private Element configItemToElement(String name, String value,
            String description) {
        Element e = new Element("Item");
        e.setAttribute("name", name);
        e.setAttribute("value", value);
        e.setAttribute("description", description);
        return e;
    }

    /**
     * �޸����÷���
     * @return true���³ɹ���falseʧ��
     */
    public boolean updateConfigType(String oldName, String newName,
            String newDescription) {
        synchronized (synchronizeObj) {
            //������oldName�ķ��࣬����false
            if (mapConfigType.containsKey(oldName) == false)
                return false;

            if (oldName.equals(newName) == false) {

                mapConfigType.remove(oldName);
                mapConfigType.put(newName, null);

                Vector vKeys = new Vector();
                for (Iterator iter = mapConfigItem.keySet().iterator(); iter
                        .hasNext();) {
                    String key = (String) iter.next();
                    if (key.startsWith(oldName + "&"))
                        vKeys.add(new String(key));
                }
                for (Iterator iter = vKeys.iterator(); iter.hasNext();) {
                    String key = (String) iter.next();
                    String newKey = newName + key.substring(key.indexOf("&"));
                    mapConfigItem.remove(key);
                    mapConfigItem.put(newKey, null);

                }
            }

            //����elemConfiguration�е����÷���
            Element elemConfigType = getElementByNameAttr(elemConfiguration,
                    oldName);
            elemConfigType.setAttribute("name", newName);
            elemConfigType.setAttribute("description", newDescription);
            try {
                //������ĵ������ļ�
                outputter.output(elemConfiguration, new FileOutputStream(
                		MosticConfigUrl));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    /**
     * ɾ�����÷���
     * @return trueɾ���ɹ���falseʧ��
     */
    public boolean delConfigType(String name) {
        synchronized (synchronizeObj) {
            if (mapConfigType.containsKey(name) == false)
                return false;
            Vector vKeys = new Vector();
            for (Iterator iter = mapConfigItem.keySet().iterator(); iter
                    .hasNext();) {
                String key = (String) iter.next();
                if (key.startsWith(name + "&"))
                    vKeys.add(new String(key));
            }
            for (Iterator iter = vKeys.iterator(); iter.hasNext();) {
                String key = (String) iter.next();
                mapConfigItem.remove(key);
            }

            Element elemConfigType = getElementByNameAttr(elemConfiguration,
                    name);
            elemConfiguration.removeContent(elemConfigType);
            try {
                //������ĵ������ļ�
                outputter.output(elemConfiguration, new FileOutputStream(
                		MosticConfigUrl));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    /**
     * ����������Ϣ��
     * @return true���ӳɹ���falseʧ��
     */
    public boolean addItem(String configTypeName, String itemName,
            String itemValue, String itemDescription) {
        synchronized (synchronizeObj) {
            //������÷��಻���ڻ��߸��������Ѿ����ڣ�����false
            if (mapConfigType.containsKey(configTypeName) == false
                    || mapConfigItem.containsKey(configTypeName + "&"
                            + itemName))
                return false;
            //��mapConfigItem�����Ӽ�¼
            mapConfigItem.put(configTypeName + "&" + itemName, null);

            //����XML��Element
            Element elemConfigType = getElementByNameAttr(elemConfiguration,
                    configTypeName);
            elemConfigType.addContent(configItemToElement(itemName, itemValue,
                    itemDescription));
            try {
                //������ĵ������ļ�
                outputter.output(elemConfiguration, new FileOutputStream(
                		MosticConfigUrl));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    /**
     * ����������Ϣ��
     * @return true���³ɹ���falseʧ��
     */
    public boolean updateItem(String configTypeName, String itemName,
            String itemValue, String itemDescription) {
        synchronized (synchronizeObj) {
            //������÷��಻���ڻ��߸���������ڣ�����false
            if (mapConfigType.containsKey(configTypeName) == false
                    || mapConfigItem.containsKey(configTypeName + "&"
                            + itemName) == false)
                return false;

            //����XML��Element
            Element elemConfigType = getElementByNameAttr(elemConfiguration,
                    configTypeName);
            Element elemConfigItem = getElementByNameAttr(elemConfigType,
                    itemName);
            elemConfigType.removeContent(elemConfigItem);
            elemConfigType.addContent(configItemToElement(itemName, itemValue,
                    itemDescription));
            try {
                //������ĵ������ļ�
                outputter.output(elemConfiguration, new FileOutputStream(
                		MosticConfigUrl));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    /**
     * ɾ��������Ϣ��
    * @return trueɾ���ɹ���falseʧ��
     */
    public boolean delItem(String configTypeName, String itemName) {
        synchronized (synchronizeObj) {
            //������÷��಻���ڻ��߸���������ڣ�����false
            if (mapConfigType.containsKey(configTypeName) == false
                    || mapConfigItem.containsKey(configTypeName + "&"
                            + itemName) == false)
                return false;

            //����XML��Element
            Element elemConfigType = getElementByNameAttr(elemConfiguration,
                    configTypeName);
            Element elemConfigItem = getElementByNameAttr(elemConfigType,
                    itemName);
            elemConfigType.removeContent(elemConfigItem);
            try {
                //������ĵ������ļ�
                outputter.output(elemConfiguration, new FileOutputStream(
                		MosticConfigUrl));
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    /**
     * ��ȡ������Ϣ���ֵ
     * @return ����Ϣ���ֵ�����������ڷ���null
     */
    public String getItemValue(String configTypeName, String itemName) {
        synchronized (synchronizeObj) {
            //�������������ڣ�����false
            if (mapConfigItem.containsKey(configTypeName + "&" + itemName)) {
                Element elemConfigType = getElementByNameAttr(
                        elemConfiguration, configTypeName);
                Element elemConfigItem = getElementByNameAttr(elemConfigType,
                        itemName);
                return elemConfigItem.getAttributeValue("value");
            }
        }
        return null;
    }

    /**
     * ��ȡ���е����÷���
     */
    public Vector getConfigTypes() {
        Vector vConfigType = new Vector();
        synchronized (synchronizeObj) {
            List listConfigType = elemConfiguration.getChildren();
            for (Iterator iter = listConfigType.iterator(); iter.hasNext();) {
                Element element = (Element) iter.next();
                String name = element.getAttributeValue("name");
                String desc = element.getAttributeValue("description");
                vConfigType.add(new ConfigType(name, desc));
            }
        }
        return vConfigType;
    }

    /**
     * ��ȡĳ�����µ�������
     */
    public Vector getConfigItems(String configTypeName) {
        Vector vConfigItem = new Vector();
        synchronized (synchronizeObj) {
            Element elemConfigType = getElementByNameAttr(elemConfiguration,
                    configTypeName);
            if (elemConfigType != null) {
                List listConfigItem = elemConfigType.getChildren();
                for (Iterator iter = listConfigItem.iterator(); iter.hasNext();) {
                    Element element = (Element) iter.next();
                    String name = element.getAttributeValue("name");
                    String value = element.getAttributeValue("value");
                    String desc = element.getAttributeValue("description");
                    vConfigItem.add(new ConfigItem(name, value, desc));
                }
            }
        }
        return vConfigItem;
    }

    public static void main(String[] args) {
        Configuration sigsitconfig = new Configuration();
        System.out.println(sigsitconfig.getItemValue("DBConnection",
                "url"));
    }
}