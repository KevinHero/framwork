package Chapter12;

import java.io.*;
import java.util.Vector;

public class FileManager {	
	ConfigManager config = new ConfigManager();
	String path= config.getItemValue("lucene", "lucenepath");
	
	public Vector getFile(){	 
		Vector v = new Vector();
		try { 		 	
		    String articleId ="";
	        FileReader fr = new FileReader(path);
	        BufferedReader br = new BufferedReader(fr);                 
	       while((articleId=br.readLine())!=null){
	       	if(articleId==null||articleId=="")
	        articleId="0";
	       	v.add(articleId);	     
	       }
	        br.close();
	        fr.close(); 
	      } catch (IOException e) { 
	        System.out.println("error.");
	        e.printStackTrace();
	      }
	      return v;
	}
	
	public void saveFile(Vector v){
		try { 				
	           FileWriter fw = new FileWriter(path);
	           BufferedWriter bw = new BufferedWriter(fw); 	           
	          for(int i=0;i<v.size();i++){
	        	  String info = (String)v.get(i);
	        	  bw.write(info);
	        	  bw.newLine();
	          }
	          bw.close();
	          fw.close();
	           } catch (IOException e) { 
	             e.printStackTrace();
	           }	         	
	}	
	public void saveFile(String v){
		try { 
			FileWriter fw = new FileWriter(path);
	        BufferedWriter bw = new BufferedWriter(fw); 
	         bw.write(v);	        		       
	          bw.close();
	          fw.close();
	           } catch (IOException e) { 
	             e.printStackTrace();
	           }	         	
	}
	
	public void delFile(String path){
			String filepath=path+"\\write.lock";
			File des = new File(filepath);
	      	des.delete();
			des=null;
		}

}
