package Chapter12;

public class ConfigClassify {
    
    private String classifyName;
    private String classifyDesc;

    public ConfigClassify(String name, String desc) {
        this.classifyName = name;
        this.classifyDesc = desc;
    }

    public String getClassifyDesc() {
        return classifyDesc;
    }

    public String getClassifyName() {
        return classifyName;
    }
}