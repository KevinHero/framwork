package Chapter12;

import java.io.*;
import java.sql.*;
import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

public class EBNVIndex {
	public static void main(String[] args) {
		
		IndexBuilerAll();
	}
	
	public static void IndexBuilerAll() {
		EBNVIndex Indexmanager = new EBNVIndex();

		ConfigManager config = new ConfigManager();
		String INDEX_DIST_PATH = config.getItemValue("Lucene", "indexpath");
		String INDEX_SRC_PATH = config.getItemValue("Lucene", "sourcepath");
		
		try {
			
			LuceneIndexLocalDisk localDiskIndexer = new LuceneIndexLocalDisk();
			
			File indexpath = new File(INDEX_DIST_PATH);
			File localPath = new File(INDEX_SRC_PATH);
			
			localDiskIndexer.indexBuilder(indexpath , localPath);
			
			databaseTool dbtoolIndexer = new databaseTool();
			dbtoolIndexer.IndexCreate(INDEX_DIST_PATH);
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	public void IndexOptimize() {
		EBNVIndex Indexmanager = new EBNVIndex();

		ConfigManager config = new ConfigManager();
		String INDEX_DIST_PATH = config.getItemValue("Lucene", "indexpath");
		
		try {
			IndexWriter writer = new IndexWriter(INDEX_DIST_PATH,new StandardAnalyzer(), false);
			writer.optimize();
			writer.close();
		} catch (IOException e) {
			System.out.println("�ļ��𻵣����ؽ���");
			return;
		}
	}

}