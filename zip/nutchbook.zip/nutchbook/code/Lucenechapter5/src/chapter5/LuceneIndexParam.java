package chapter5;

import java.io.IOException;

import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

public class LuceneIndexParam {
	
	private static String Dest_Index_Path = "D:\\workshop\\TextIndex";
	
	static protected String[] keywords = {"001","002","003"};
	static protected String[] textdetail = {  "��¼һ ����һ ����� ������"
		                                    , "��¼�� ����һ ����� ������"
		                                    , "��¼�� ����һ ����� ������"} ;
	
	public static void main(String[] args) {
		
		try {
			
			Analyzer TextAnalyzer = new SimpleAnalyzer();
			IndexWriter TextIndex = new IndexWriter(Dest_Index_Path,TextAnalyzer,true);
	        TextIndex.setUseCompoundFile(true);
	        
			System.out.print("Default MergeFactor: ");
			System.out.println(TextIndex.getMergeFactor());
			System.out.print("Default MaxBufferedDocs: ");
			System.out.println(TextIndex.getMaxBufferedDocs());
			System.out.print("Default TermIndexInterval: ");
			System.out.println(TextIndex.getTermIndexInterval());
			System.out.print("Default MaxBufferedDeleteTerms: ");
			System.out.println(TextIndex.getMaxBufferedDeleteTerms());
			
	        TextIndex.setMergeFactor(20);
	        TextIndex.setMaxBufferedDocs(10);
	        TextIndex.setMaxBufferedDeleteTerms(10);
	        TextIndex.setTermIndexInterval(10);
	        
			for(int i = 0; i < 3 ; i++){
				
				TextIndex.setMaxFieldLength(i);
				Document document = new Document();
				
				Field field_id = new Field("id", keywords[i], 
						Field.Store.YES,Field.Index.UN_TOKENIZED);
				
				document.add(field_id);
				
				Field field_content = new Field("content", textdetail[i], 
						Field.Store.YES,Field.Index.TOKENIZED);
				
				document.add(field_content);
		
				TextIndex.addDocument(document);

			}
			System.out.println("Change Param... ");
			

			System.out.print("Current MergeFactor: ");
			System.out.println(TextIndex.getMergeFactor());
			System.out.print("Current MaxBufferedDocs: ");
			System.out.println(TextIndex.getMaxBufferedDocs());
			System.out.print("Current TermIndexInterval: ");
			System.out.println(TextIndex.getTermIndexInterval());
			System.out.print("Current MaxBufferedDeleteTerms: ");
			System.out.println(TextIndex.getMaxBufferedDeleteTerms());
			
			TextIndex.optimize();
			
			TextIndex.close();			

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
}


