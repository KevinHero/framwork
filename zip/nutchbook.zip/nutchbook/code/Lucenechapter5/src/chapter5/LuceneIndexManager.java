package chapter5;

import java.util.Date;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;

import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

public class LuceneIndexManager {

	private static String Dest_Index_Path = "D:\\workshop\\TextIndex1";
	private static String Text_File_Path = "D:\\workshop\\ch2\\aximofu.txt";
	private static String Text_update_Path = "D:\\workshop\\ch2\\introduction.txt";

	public static void main(String[] args) {
		      
		try {
			
			Date start = new Date();
			
			File file = new File(Text_File_Path);
	        FileReader fpReader = new FileReader(file);

	        Directory dir = FSDirectory.getDirectory(Dest_Index_Path,false);
	        Analyzer TextAnalyzer = new SimpleAnalyzer();
	        IndexWriter TextIndex = new IndexWriter(dir,TextAnalyzer,false);
	        TextIndex.setUseCompoundFile(true);
			Document document = new Document();

			Field field_name = new Field("path", file.getName(), 
					Field.Store.YES,Field.Index.UN_TOKENIZED);
			document.add(field_name);
			
			FileInputStream inputfile=new FileInputStream(file); 
			int len=inputfile.available();
			byte[] buffer = new byte[len]; 
			inputfile.read(buffer);
			inputfile.close();
						
			String contentext = new String(buffer);			
			Field field_content = new Field("content", contentext,
					 Field.Store.YES,Field.Index.TOKENIZED);
			document.add(field_content);
			
			TextIndex.addDocument(document);
		
			
			TextIndex.optimize();
			TextIndex.close();
			Date end = new Date();
			long tm_index = end.getTime() - start.getTime(); 

			System.out.println("Total Time:(ms)");
			System.out.println(tm_index);

		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Index success");
	}
}

