package chapter5;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

public class LuceneIndexDeleteId {
	public static void main(String[] args) {
		
		try {
			File indexDir = new File("D:\\workshop\\TextIndex"); 
			IndexReader reader = IndexReader.open(indexDir);            

			System.out.print("Next  Document ID  before delete: ");
			System.out.println(reader.maxDoc());
			System.out.print("Total Document Num before delete: ");
			System.out.println(reader.numDocs());
			
			reader.deleteDocument(0);
			
			System.out.print("Next  Document ID  after delete: ");
			System.out.println(reader.maxDoc());
			System.out.print("Total Document Num after delete: ");
			System.out.println(reader.numDocs());
		
			reader.undeleteAll();
			
			System.out.print("Next  Document ID  after undelete: ");
			System.out.println(reader.maxDoc());
			System.out.print("Total Document Num after undelete: ");
			System.out.println(reader.numDocs());
			
			reader.close();

		}catch (IOException e) {
			e.printStackTrace();
		}
	}
}
