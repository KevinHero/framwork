package chapter5;

import java.util.Date;
import java.io.IOException;

import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

public class LuceneIndexText {
	
	private static String Dest_Index_Path = "D:\\workshop\\TextIndex";
	
	static protected String[] keywords = {"001","002","003"};
	static protected String[] textdetail = {"��¼һ","��¼��", "��¼��"} ;
	
	public static void main(String[] args) {
		
		try {
			
			Date start = new Date();
			
			Analyzer TextAnalyzer = new SimpleAnalyzer();
			IndexWriter TextIndex = new IndexWriter(Dest_Index_Path,TextAnalyzer,true);
	        TextIndex.setUseCompoundFile(true);
			for(int i = 0; i < 3 ; i++){
				Document document = new Document();
				
				Field field_id = new Field("id", keywords[i], 
						Field.Store.YES,Field.Index.UN_TOKENIZED);
				
				document.add(field_id);
				
				Field field_content = new Field("content", textdetail[i], 
						Field.Store.YES,Field.Index.TOKENIZED);
				
				document.add(field_content);
		
				TextIndex.addDocument(document);

			}
			
			TextIndex.optimize();
			TextIndex.close();
			Date end = new Date();
			long tm_index = end.getTime() - start.getTime(); 

			System.out.println("Total Time:(ms)");
			System.out.println(tm_index);

		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Index success");

	}
	
}
