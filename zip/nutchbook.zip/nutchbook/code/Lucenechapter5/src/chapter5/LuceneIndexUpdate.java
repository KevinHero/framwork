package chapter5;

import java.util.Date;
import java.io.*;

import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

public class LuceneIndexUpdate {

	private static String Dest_Index_Path = "D:\\workshop\\TextIndex1";
	private static String Text_File_Path = "D:\\workshop\\ch2\\indexsample.txt";
	private static String Text_update_Path = "D:\\workshop\\ch2\\indexsample2.txt";

	public static void main(String[] args) {
	
		try {
			File file = new File(Text_File_Path);  // ԭʼ�ļ�
	        Directory dir = FSDirectory.getDirectory(Dest_Index_Path,false); // ����Ŀ¼
	        Analyzer TextAnalyzer = new SimpleAnalyzer();                    // �ĵ�������
	        IndexWriter TextIndex = new IndexWriter(dir,TextAnalyzer,true);  // ��������������
	        TextIndex.setUseCompoundFile(true);
			Document document = new Document();                              // �½����ĵ�

			Field field_name = new Field("path", file.getName(), 
					Field.Store.YES,Field.Index.UN_TOKENIZED);
			document.add(field_name);                                        // �����ļ�����

			FileInputStream inputfile=new FileInputStream(file);             // �ļ�������
			int len=inputfile.available();
			byte[] buffer = new byte[len]; 
			inputfile.read(buffer);                                          // ��ȡ�ļ�����
			inputfile.close();
			
			String contentext = new String(buffer);
			Field field_content = new Field( "content", contentext,
					                         Field.Store.YES,Field.Index.TOKENIZED );
			document.add(field_content);                                    // �����ļ�������
			TextIndex.addDocument(document);                                // ���������ĵ�
			TextIndex.optimize();
			TextIndex.close();
			display(file.getName());                                        // ����滻ǰ���
			
	        IndexWriter TextIndex2 = new IndexWriter(dir,TextAnalyzer,true); // �ؽ�������
	        TextIndex2.setUseCompoundFile(true); 

			File file2 = new File(Text_update_Path);			
			Document document2 = new Document();                             // ���ɿ��ĵ�����
			Field field_name2 = new Field("path", file2.getName(),           // �����ļ����� 
					Field.Store.YES,Field.Index.UN_TOKENIZED);
			document2.add(field_name2);
			FileInputStream inputfile2=new FileInputStream(file2);           // ��ȡ�ļ�����
			int len2=inputfile2.available();
			byte[] buffer2 = new byte[len2]; 
			inputfile2.read(buffer2);
			inputfile2.close();
			
			String contentext2 = new String(buffer2);
			Field field_content2 = new Field( "content", contentext2,
					                         Field.Store.YES,Field.Index.TOKENIZED );
			document2.add(field_content2);                                  // �����ļ�������
			//Term term = new Term("path", file.getName() );                  // �½���㵥Ԫ
			Term term = new Term("content", "Lucene" );                  // �½���㵥Ԫ
			TextIndex2.updateDocument(term, document2);                     // �滻ԭ��ƥ���ĵ�
			TextIndex2.optimize();
			TextIndex2.close();
			display(file2.getName());                                       // ����滻����
			
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public static void display(String words) throws IOException
	{	// ��ʾ���
		try {		
			IndexSearcher searcher = new IndexSearcher( Dest_Index_Path ); // ������
			Term term = new Term("path", words );                          // ������
			Query query = new TermQuery(term);                             // ������Ԫ 
			System.out.println("Query  words:");
			System.out.println("  " + query.toString());
			Hits hits = searcher.search(query);                            // �ύ����
			System.out.println("Search result:");
			for(int i=0; i < hits.length(); i++)                           // ������
			{
				if( hits.doc(i).getField("content")!= null)
				 System.out.println("  Content: " + hits.doc(i).getField("content").stringValue());			
				
				System.out.println("   Path : " + hits.doc(i).getField("path").stringValue());
			}
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}

