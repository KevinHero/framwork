package chapter5;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

public class LuceneIndexDeleteOptimize {
	public static void main(String[] args) {
		
		try {
			File indexDir = new File("D:\\workshop\\TextIndex"); 
			IndexReader reader = IndexReader.open(indexDir);            

			System.out.print("Next  Document ID  before optimize: ");
			System.out.println(reader.maxDoc());
			System.out.print("Total Document Num before optimize: ");
			System.out.println(reader.numDocs());
			
			reader.close();
			
			IndexWriter idxwriter = new IndexWriter("D:\\workshop\\TextIndex",new SimpleAnalyzer(),false);
			Term term = new Term("id","002");
			idxwriter.deleteDocuments(term);
			idxwriter.optimize();
			idxwriter.close();

			reader = IndexReader.open(indexDir);            

			System.out.print("Next  Document ID  after optimize: ");
			System.out.println(reader.maxDoc());
			System.out.print("Total Document Num after optimize: ");
			System.out.println(reader.numDocs());
			
			reader.close();			
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
}
