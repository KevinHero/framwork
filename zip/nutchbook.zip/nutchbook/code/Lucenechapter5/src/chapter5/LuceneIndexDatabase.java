package chapter5;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jeasy.analysis.MMAnalyzer;

import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

/*******************************************************************
 * ������������ݿ�ļ�¼���ʺ�����������JDBC�������ݿ��¼������Lucene����
 * ������Ϊ��������ʹ������׼����
 *******************************************************************/
public class LuceneIndexDatabase {

	private static String Dest_Index_Path = "D:\\workshop\\DataBaseIndex";
	
	private static Connection conn = null;
	private static Statement statmt = null;
	private static ResultSet record = null;
	
	/*========================================================
	 * ��������ָ������Ŀ¼�ʹ�������Ŀ¼������Lucene����
	 *========================================================*/
	public static void main(String[] args) {
		
		
		try {
			File indexpath = new File(Dest_Index_Path);
	   		IndexWriter Writer = new IndexWriter(indexpath,new StandardAnalyzer(),true);
			
			getGetConn("sa","sa","lucenedb");
			record = getResultSet("select * from  T_Abstrac");
			DbIndexBuilder(Writer);
			
			Writer.optimize();			
			Writer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/*========================================================
	 * ��ȡ���ݿ����ӣ�ȡ��SQL�����ľ����
	 *========================================================*/
	public static void getGetConn(String dbname, String user,String passwd) throws IOException{

		try {
			Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver")
					.newInstance();
		} catch (InstantiationException e2) {
			e2.printStackTrace();
		} catch (IllegalAccessException e2) {
			e2.printStackTrace();
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}
		
		String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=" + dbname;

		try {
			conn = DriverManager.getConnection(url, user, passwd);
		} catch (SQLException e2) {
			e2.printStackTrace();
		}

	}
	
	/*========================================================
	 * ��ȡ��¼��������ָ�������������ݿ⣬��ȡ���
	 *========================================================*/
	public static ResultSet getResultSet(String sqlstate) 
	throws IOException{
	      try{
	          Statement statmt = conn.createStatement();
	          ResultSet rs = statmt.executeQuery(sqlstate);
	          return rs;
	        }
	        catch(SQLException e){
	          System.out.println(e);
	        }
	        return null;

	}	

	/*========================================================
	 * �������ݼ�¼��RAM�ڴ����������ɲ������ĵ����ϲ������ش�����������
	 *========================================================*/
	private static void  DbIndexBuilder(IndexWriter fswriter)  
	throws IOException{
	
        while( record.next()){
    		Directory ramdirectory = new RAMDirectory();
    		IndexWriter RAMWriter = new IndexWriter(ramdirectory,new StandardAnalyzer(),true);
    		
    		Document document = new Document();
    		Field field_id = new Field("Id", record.getString(0), 
    				Field.Store.YES,Field.Index.UN_TOKENIZED);
    		document.add(field_id);
    		
     		Field field_name = new Field("Name", record.getString(1), 
    				Field.Store.YES,Field.Index.UN_TOKENIZED);
    		document.add(field_name);
    		
    		Field field_source = new Field("Source", record.getString(2), 
    				Field.Store.YES,Field.Index.UN_TOKENIZED);
    		document.add(field_source);
    		
       		Field field_abstract = new Field("Abstract", record.getString(3), 
    				Field.Store.YES,Field.Index.UN_TOKENIZED);
    		document.add(field_abstract);
   		
    		RAMWriter.addDocument(document);
    		RAMWriter.close();      	
    		fswriter.addIndexes(new Directory[]{ramdirectory});
       }
	}

}

