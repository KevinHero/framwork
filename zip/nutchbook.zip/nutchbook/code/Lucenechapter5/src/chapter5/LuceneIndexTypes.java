package chapter5;

import java.util.Date;
import java.io.*;

import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

public class LuceneIndexTypes {

	private static String Dest_Index_Path = "D:\\workshop\\TextIndexstore";
	private static String Dest_Index_Path_un = "D:\\workshop\\TextIndexunstore";
	private static String Dest_Index_Path_Zip = "D:\\workshop\\TextIndexZip";
	private static String Text_File_Path = "D:\\workshop\\ch2\\wholeaximofu.txt";

	public static void main(String[] args) {
		      
		try {
			indexstore();
			indexunstore();
			indexcompress();
			System.out.println(" index sucess.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void indexstore() throws IOException
	{
		File file = new File(Text_File_Path);  // ԭʼ�ļ�
        Directory dir = FSDirectory.getDirectory(Dest_Index_Path,false); // ����Ŀ¼
        Analyzer TextAnalyzer = new SimpleAnalyzer();                    // �ĵ�������
        IndexWriter TextIndex = new IndexWriter(dir,TextAnalyzer,true);  // ��������������
        TextIndex.setUseCompoundFile(true);
		Document document = new Document();                              // �½����ĵ�

		Field field_name = new Field("path", file.getName(), 
				Field.Store.YES,Field.Index.UN_TOKENIZED);
		document.add(field_name);                                        // �����ļ�����

		FileInputStream inputfile=new FileInputStream(file);             // �ļ�������
		int len=inputfile.available();
		byte[] buffer = new byte[len]; 
		inputfile.read(buffer);                                          // ��ȡ�ļ�����
		inputfile.close();
		
		String contentext = new String(buffer);
		Field field_content = new Field( "content", contentext,          // �ı��򱣴�����
				                         Field.Store.YES,Field.Index.TOKENIZED );
		document.add(field_content);                                    // �����ļ�������
		TextIndex.addDocument(document);                                // ���������ĵ�
		TextIndex.optimize();
		TextIndex.close();
		
		System.out.println("########## Index Stored ##########");
		display(Dest_Index_Path , file.getName());
	}
	
	public static void indexunstore( ) throws IOException
	{
		File file = new File(Text_File_Path);  // ԭʼ�ļ�
        Directory dir = FSDirectory.getDirectory(Dest_Index_Path_un,false); // ����Ŀ¼
        Analyzer TextAnalyzer = new SimpleAnalyzer();                    // �ĵ�������
        IndexWriter TextIndex = new IndexWriter(dir,TextAnalyzer,true);  // ��������������
        TextIndex.setUseCompoundFile(true);
		Document document = new Document();                              // �½����ĵ�

		Field field_name = new Field("path", file.getName(), 
				Field.Store.YES,Field.Index.UN_TOKENIZED);
		document.add(field_name);                                        // �����ļ�����

		FileInputStream inputfile=new FileInputStream(file);             // �ļ�������
		int len=inputfile.available();
		byte[] buffer = new byte[len]; 
		inputfile.read(buffer);                                          // ��ȡ�ļ�����
		inputfile.close();
		
		String contentext = new String(buffer);
		Field field_content = new Field( "content", contentext,          // �ı��򲻱�������
				                         Field.Store.NO,Field.Index.TOKENIZED );
		document.add(field_content);                                    // �����ļ�������
		TextIndex.addDocument(document);                                // ���������ĵ�
		TextIndex.optimize();
		TextIndex.close();
		
		System.out.println("########## Index UnStored ##########");
		
		display(Dest_Index_Path_un , file.getName());		
	}
	public static void indexcompress() throws IOException
	{
		File file = new File(Text_File_Path);  // ԭʼ�ļ�
        Directory dir = FSDirectory.getDirectory(Dest_Index_Path_Zip,false); // ����Ŀ¼
        Analyzer TextAnalyzer = new SimpleAnalyzer();                    // �ĵ�������
        IndexWriter TextIndex = new IndexWriter(dir,TextAnalyzer,true);  // ��������������
        TextIndex.setUseCompoundFile(true);
		Document document = new Document();                              // �½����ĵ�

		Field field_name = new Field("path", file.getName(), 
				Field.Store.YES,Field.Index.UN_TOKENIZED);
		document.add(field_name);                                        // �����ļ�����

		FileInputStream inputfile=new FileInputStream(file);             // �ļ�������
		int len=inputfile.available();
		byte[] buffer = new byte[len]; 
		inputfile.read(buffer);                                          // ��ȡ�ļ�����
		inputfile.close();
		
		String contentext = new String(buffer);
		Field field_content = new Field( "content", contentext,          // �ı��򱣴�����
				                         Field.Store.COMPRESS,Field.Index.TOKENIZED );
		document.add(field_content);                                    // �����ļ�������
		TextIndex.addDocument(document);                                // ���������ĵ�
		TextIndex.optimize();
		TextIndex.close();
		
		System.out.println("########## Index Compress ##########");
		display(Dest_Index_Path_Zip , file.getName());
		
	}
	
	public static void display(String indexpath, String words) throws IOException
	{	// ��ʾ���
		try {		
			IndexSearcher searcher = new IndexSearcher( indexpath ); // ������
			Term term = new Term("path", words );                          // ������
			Query query = new TermQuery(term);                             // ������Ԫ 
			System.out.println("Query  words:");
			System.out.println("  " + query.toString());
			Hits hits = searcher.search(query);                            // �ύ����
			System.out.println("Search result:");
			for(int i=0; i < hits.length(); i++)                           // ������
			{
				System.out.println("  Path: " + hits.doc(i).getField("path").stringValue());
				if( hits.doc(i).getField("content")!= null)
				  System.out.println("  Content: " + hits.doc(i).getField("content").stringValue());			
				
			}
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}

