package chapter5;

import java.util.Date;
import java.io.*;

import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.queryParser.*;

public class LuceneIndexInteger {

	private static String Dest_Index_Path = "D:\\workshop\\TextIndex1";
	private static String Text_File_Path = "D:\\workshop\\ch2\\indexsample.txt";

	public static void main(String[] args) {
	
		try {
			File file = new File(Text_File_Path);  // ԭʼ�ļ�
	        Directory dir = FSDirectory.getDirectory(Dest_Index_Path,false); // ����Ŀ¼
	        Analyzer TextAnalyzer = new SimpleAnalyzer();                    // �ĵ�������
	        IndexWriter TextIndex = new IndexWriter(dir,TextAnalyzer,true);  // ��������������
	        TextIndex.setUseCompoundFile(true);
			Document document = new Document();                              // �½����ĵ�

			Field field_name = new Field("path1", file.getName(), 
					Field.Store.YES,Field.Index.UN_TOKENIZED);
			document.add(field_name);                                        // ���������ļ�����
			
			Field field_name2 = new Field("path2", file.getName(), 
					Field.Store.YES,Field.Index.TOKENIZED);
			document.add(field_name2);                                      // ���������ļ�����

			TextIndex.addDocument(document);                                // ���������ĵ�
			TextIndex.optimize();
			TextIndex.close();
			
			System.out.println("----------no split-----------------");
			display(file.getName(),true);                                   // ����滻ǰ���
			System.out.println("----------  split  ----------------");			
			display(file.getName(),false);                                   // ����滻ǰ���

		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public static void display(String words,boolean bsplit) throws IOException
	{	// ��ʾ���
		Query query ,query1;
		try {		
			IndexSearcher searcher = new IndexSearcher( Dest_Index_Path ); // ������
			if(bsplit)
			{
				Term term = new Term("path2", words);                      // ������
				query = new TermQuery(term);                               // ������Ԫ 
				Term term1 = new Term("path1", words);                      // ������
				query1 = new TermQuery(term1);                              // ������Ԫ 
				
			} else {
			    QueryParser parser = new QueryParser("path2",new StandardAnalyzer()); 
			    query = parser.parse(words);
			    QueryParser parser1 = new QueryParser("path1",new StandardAnalyzer()); 
			    query1 = parser1.parse(words);
			}

			System.out.println("Query  words:");
			System.out.println("  " + query.toString());
			Hits hits = searcher.search(query );                           // �ύ����
			System.out.println("Search result:");
			for(int i=0; i < hits.length(); i++)                           // ������
			{
				System.out.println("  path2: " + hits.doc(i).getField("path2").stringValue());			
				System.out.println("   Path1 : " + hits.doc(i).getField("path1").stringValue());
			}
			
			System.out.println("Query  words:");
			System.out.println("  " + query1.toString());
			hits = searcher.search(query1 );                               // �ύ����
			System.out.println("Search result:");
			for(int i=0; i < hits.length(); i++)                           // ������
			{
				System.out.println("  path2: " + hits.doc(i).getField("path2").stringValue());			
				System.out.println("   Path1 : " + hits.doc(i).getField("path1").stringValue());
			}			
		} catch (ParseException e)
		{
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}

