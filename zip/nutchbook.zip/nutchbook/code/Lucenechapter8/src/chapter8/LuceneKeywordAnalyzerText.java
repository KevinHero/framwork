package chapter8;

import java.io.IOException;

import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.KeywordAnalyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Token;

import java.util.*;
import java.io.*;

public class LuceneKeywordAnalyzerText {
	
	private static String Dest_Index_Path = "D:\\workshop\\TextIndex";
//	static protected String textdetail = "Lucene works very well,it is very useful." ;
	static protected String textdetail = "Lucene��һ���ǳ���Ч�Ŀ������ߣ�������ʵ��ȫ�ļ������ܡ�" ;
	
	public static void main(String[] args) {
		try {
			Analyzer TextAnalyzer = new KeywordAnalyzer();
			IndexWriter TextIndex = new IndexWriter(Dest_Index_Path,TextAnalyzer,true);
			Document document = new Document();
			Field field_content = new Field("content", textdetail, 
					Field.Store.YES,Field.Index.TOKENIZED);
			document.add(field_content);
			TextIndex.addDocument(document);
			
			ArrayList ItemList = new ArrayList();
			
			TokenStream stream = TextAnalyzer.tokenStream("content", new StringReader(textdetail));
			while(true)
			{
				Token item = stream.next();
				if(null == item ) break;
				System.out.print("{"+item.termText()+"} ");
			}
			TextIndex.optimize();
			TextIndex.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("");
		System.out.println("Index success");
	}
}
