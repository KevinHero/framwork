package chapter8;


import java.io.IOException;

import org.apache.lucene.index.Term;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.analysis.standard.*;

import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.IndexSearcher;

public class LuceneSearchAnalyzer {
	
	private static String Dest_Index_Path = "D:\\workshop\\TextIndex";
	
	static protected String[] keywords = {"001","002","003"};
	static protected String[] textdetail = {"��¼ һ","��¼ ��", "��¼ ��"} ;
	
	/*================================================================
	 * �� �ƣ�QueryIndex
	 * �� �ܣ����������ѯ������ָ����Ŀ¼���в�ѯ���ҵ�ָ����ֵ���������Ӧ�����
	 ===============================================================*/
	public static void QueryIndex(){
		
		try {
			IndexSearcher searcher = new IndexSearcher(Dest_Index_Path);
			Term term = new Term("id","002");
			//Term term = new Term("content","��¼");
			Query query = new TermQuery(term);
			System.out.println(query.toString());

			Hits hits = searcher.search(query);
			
			System.out.println("Search result:");
			
			for(int i=0; i < hits.length(); i++)
			{
				System.out.println(hits.doc(i));
				System.out.println(hits.doc(i).getField("id"));			
			}
			
		}catch (IOException e) {
				e.printStackTrace();
		}

		System.out.println("Search success");		
		
	}
	
	/*================================================================
	 * �� �ƣ�IndexBuilder
	 * �� �ܣ���������������������ݵ�ָ��Ŀ¼��Ϊ����������ѯ����׼����
	 ===============================================================*/
	public static void IndexBuilder(){
		
		try {
			
			Analyzer TextAnalyzer = new SimpleAnalyzer();
			IndexWriter TextIndex = new IndexWriter(Dest_Index_Path,TextAnalyzer,true);
	        TextIndex.setUseCompoundFile(true);
			for(int i = 0; i < 3 ; i++){
				Document document = new Document();
				
				Field field_id = new Field("id", keywords[i], 
						Field.Store.YES,Field.Index.UN_TOKENIZED);
				
				document.add(field_id);
				
				Field field_content = new Field("content", textdetail[i], 
						Field.Store.YES,Field.Index.TOKENIZED);
				
				document.add(field_content);
				
				TextIndex.addDocument(document);

			}
			TextIndex.optimize();
			TextIndex.close();
		
		}catch (IOException e) {
				e.printStackTrace();
		}

		System.out.println("Index success");		
	}
	
	/*================================================================
	 * �� �ƣ�IndexMultiAnalyzerBuilder
	 * �� �ܣ���������������������ݵ�ָ��Ŀ¼��Ϊ����������ѯ����׼����
	 ===============================================================*/
	public static void IndexMultiAnalyzerBuilder(){
		
		try {
			
			Analyzer TextAnalyzer = new WhitespaceAnalyzer();
			Analyzer DocumentAnalyzer = new StandardAnalyzer();
			IndexWriter TextIndex = new IndexWriter(Dest_Index_Path,TextAnalyzer,true);
	        TextIndex.setUseCompoundFile(true);
			for(int i = 0; i < 3 ; i++){
				Document document = new Document();
				
				Field field_id = new Field("id", keywords[i], 
						Field.Store.YES,Field.Index.UN_TOKENIZED);
				
				document.add(field_id);
				
				Field field_content = new Field("content", textdetail[i], 
							Field.Store.YES,Field.Index.TOKENIZED);
				document.add(field_content);

				if( 1 == i )
				{
					TextIndex.addDocument(document);
				} else {
					TextIndex.addDocument(document,DocumentAnalyzer);
				}
			}
			TextIndex.optimize();
			TextIndex.close();
		
		}catch (IOException e) {
				e.printStackTrace();
		}

		System.out.println("Index success");		
	}	
	
	
	/*================================================================
	 * �� �ƣ�QueryAnalyzerTest
	 * �� �ܣ����������ѯ����ʹ��ָ���ķ������Լ����ʽ��з������ҵ���Ӧ��������
	 ===============================================================*/
	public static void QueryAnalyzerTest(){
	
		try {
			Analyzer analyzer1 = new WhitespaceAnalyzer();
			Analyzer analyzer2 = new StandardAnalyzer();
			
			IndexSearcher searcher = new IndexSearcher(Dest_Index_Path);
		    String searchWords = "��¼";
		    QueryParser parser1 = new QueryParser("content",analyzer1); 
		    QueryParser parser2 = new QueryParser("content",analyzer2); 
		    
		    try{
			    Query query = parser1.parse(searchWords);
				System.out.println(query.toString());
				System.out.println(query.getClass());
	
				Hits hits = searcher.search(query);
				
				System.out.println("Search result:");	
				
				for(int i=0; i < hits.length(); i++)
				{
					//System.out.println(hits.doc(i));
					System.out.println(hits.doc(i).getField("id"));
					System.out.println(hits.doc(i).getField("content"));
				}
				
			    Query query2 = parser2.parse(searchWords);
				System.out.println(query2.toString());
				System.out.println(query2.getClass());
	
				Hits hits2 = searcher.search(query2);
				
				System.out.println("Search result:");	
				
				for(int i=0; i < hits2.length(); i++)
				{
					//System.out.println(hits2.doc(i));
					System.out.println(hits2.doc(i).getField("id"));	
					System.out.println(hits2.doc(i).getField("content"));
				}				
		    
		    } catch(ParseException e1){
				e1.printStackTrace();
		    }
		}catch (IOException e) {
				e.printStackTrace();
		}
		System.out.println("Search success");		
	}	
	/*================================================================
	 * �� �ƣ�main
	 * �� �ܣ�����Lucene���������ͼ�����ѯ���ܡ�
	 ===============================================================*/
	public static void main(String[] args) {
		
		//IndexBuilder();
		//QueryIndex();

		IndexMultiAnalyzerBuilder();
		QueryAnalyzerTest();
		
		System.out.println("Test success");
	}

}
