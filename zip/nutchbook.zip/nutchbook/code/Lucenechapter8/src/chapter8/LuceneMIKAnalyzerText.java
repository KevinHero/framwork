package chapter8;

import java.io.IOException;

import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Token;

import org.mira.lucene.analysis.MIK_CAnalyzer;

import java.util.*;
import java.io.*;

public class LuceneMIKAnalyzerText {
	
	private static String Dest_Index_Path = "D:\\workshop\\TextIndex";
	static protected String chinesedetail = "�����ĵ���������Ľṹ�Ǿ��ӡ�����ʻ㡢�����ĺ��֡����Ļ����ľ���ͨ���������ñ��������ָ���" ;

	public static void main(String[] args) {
		try {
			Analyzer TextIKAnalyzer = new MIK_CAnalyzer();
			
			IndexWriter TextIndex = new IndexWriter(Dest_Index_Path,TextIKAnalyzer,true);
			Document document = new Document();
			Field field_content = new Field("content", chinesedetail, 
					Field.Store.YES,Field.Index.TOKENIZED);
			document.add(field_content);
			TextIndex.addDocument(document);
			
			TokenStream stream = TextIKAnalyzer.tokenStream("content", new StringReader(chinesedetail));
			while(true)
			{
				Token item = stream.next();
				if(null == item ) break;
				System.out.print("{"+item.termText()+"} ");
			}
			TextIndex.optimize();
			TextIndex.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("");
		System.out.println("Index success");
	}
}
