package chapter9;

import org.htmlparser.util.*;
import org.htmlparser.Parser;
import org.htmlparser.filters.*;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.NodeFilter;
import org.htmlparser.nodes.TextNode;
import org.htmlparser.lexer.*;
import org.htmlparser.lexer.Stream;
import org.htmlparser.Node;
import java.io.*;
import java.net.*;

import org.htmlparser.http.ConnectionManager;
import org.htmlparser.visitors.TextExtractingVisitor;
import org.htmlparser.filters.TagNameFilter;
import org.htmlparser.filters.HasSiblingFilter;

import org.htmlparser.util.ParserException;


public class HtmlParserGetBaiduUrls {

	  public static void main (String[] args) throws ParserException
	  {
		  try {
 			  getBaiduUrls("http://www.baidu.com/s?lm=0&si=&rn=10&ie=gb2312&ct=0&wd=Lucene&pn=0&ver=0&cl=3","GB2312");
		  } catch(ParserException e)
		  {
			  e.printStackTrace();
		  }
 	  }
	  
	  public static void getBaiduUrls(String url , String pageEncoding)  throws ParserException
	  { 
		  NodeList nodeList = null;
		  try { 
			   Parser parser = new Parser(url);
		       parser.setEncoding(pageEncoding);                            // ���ý��������ʽ
			   // Baidu ���������url���Ӻͱ���
		       nodeList = parser.parse( new AndFilter( new HasAttributeFilter("target") , 
		    		                                   new HasAttributeFilter("onclick")));
			   } catch (ParserException e) { 
				   e.printStackTrace();
			   }
			  if(nodeList != null && nodeList.size() > 0) {                 // ѭ������ÿ��Url�ڵ�
				   for(int i = 0; i < nodeList.size(); i ++) {
					   String urlLink = ((LinkTag)nodeList.elementAt(i)).extractLink();
					   String LinkName = ((LinkTag)nodeList.elementAt(i)).getLinkText();
					   
					   if( urlLink.indexOf("bnu") == 0 || urlLink.indexOf("http") == 0 )
						   System.out.println("��� "+ i +" ���⣺"+LinkName);
						   System.out.println("       ���ӣ�"+urlLink );
				    }
			  }
	  }
	  
}	 	  

