package Chapter1;

public class HelloEclipse {
	 public static void main(String args[]){
		 System.out.println("Hello Eclipse"); 
		 }
}
