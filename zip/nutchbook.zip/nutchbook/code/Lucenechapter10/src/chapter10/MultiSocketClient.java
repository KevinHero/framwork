package chapter10;

import java.net.*;
import java.io.*;


public class MultiSocketClient {
		
		static final int MAX_THREADS=10;
		public static void main(String[] args)throws IOException,InterruptedException {
		InetAddress addr=InetAddress.getByName(null);
		while (true){
			if( SockClient.threadCount() == 0) 
				new SockClient(addr);
			
			Thread.currentThread().sleep(100);
		}
		}

}
