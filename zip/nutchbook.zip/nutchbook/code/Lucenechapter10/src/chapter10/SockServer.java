package chapter10;

import java.io.*;
import java.net.*;

public class SockServer extends Thread {
	 private Socket socket;
	 private BufferedReader in;
	 private PrintWriter out;
	 private String content;
	public SockServer(Socket sock,String strcont)throws IOException {
		 socket=sock;
		 content=strcont;
		 in=new BufferedReader(
		 new InputStreamReader(
		 socket.getInputStream()));
		 out=new PrintWriter(
		 new BufferedWriter(
		 new OutputStreamWriter(
		 socket.getOutputStream())),true);
		 start();
	}
	public void run(){
		 try{
			 while (true){
			 String str=in.readLine();
			 if (str.equals("END"))break;
			 System.out.println("Echoing:"+str);
			 out.println(str);
			 out.println(content);
			 }
			 System.out.println("Closing...");
		 }catch(IOException e){ 
		 }finally{
		 try{
		 socket.close();
		 }catch(IOException e){}
		 }
	}
}

