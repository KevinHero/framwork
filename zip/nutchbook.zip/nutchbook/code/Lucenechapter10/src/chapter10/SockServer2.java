package chapter10;

import java.io.*;
import java.net.*;

import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Token;
import org.apache.lucene.index.*;
import org.apache.lucene.search.*;
import java.io.IOException;
import java.util.Date;

import org.apache.lucene.index.Term;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;

import org.apache.lucene.search.Query;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.queryParser.*;
import org.apache.lucene.search.highlight.*;

import org.apache.lucene.search.BooleanQuery;

import org.apache.lucene.store.Directory; 
import org.apache.lucene.store.RAMDirectory;

import org.apache.lucene.search.DefaultSimilarity;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.search.payloads.BoostingTermQuery;

public class SockServer2 extends Thread {
	 private Socket socket;
	 private BufferedReader in;
	 private PrintWriter out;
	 private String content;
	 private  Lucenesearch searchtool = new Lucenesearch();
	 public SockServer2(Socket sock,String strcont)throws IOException {
		 socket=sock;
		 content=strcont;
		 in=new BufferedReader(
		 new InputStreamReader(
		 socket.getInputStream()));
		 out=new PrintWriter(
		 new BufferedWriter(
		 new OutputStreamWriter(
		 socket.getOutputStream())),true);
		 start();
	}
	public void run(){
		 try{
			 while (true){
				 String str=in.readLine();
				 if (str.equals("END"))break;
				 System.out.println("Echoing:"+str);
				 String result = searchtool.search(str);
				 out.write(result);
			 }
			 System.out.println("Closing...");
		 }catch(IOException e){ 
		 }finally{
		 try{
		 socket.close();
		 }catch(IOException e){}
		 }
	}
	
	private class Lucenesearch {

		 public Lucenesearch(){
		  try{
		   searcher = new IndexSearcher(IndexReader.open("D:\\workshop\\pdfindex"));
		  }catch(Exception e){
		   e.printStackTrace();
		  }
		 }
		 
		 //����һ��IndexSearcher����
		 private IndexSearcher searcher = null;
		 //����һ��Query����
		 private Query query = null;
		 StandardAnalyzer analyzer = new StandardAnalyzer();
		 Highlighter highlighter = null;
		 public final Hits search(String keyword){
			 
		  System.out.println("���ڼ����ؼ���:"+keyword);
		  try{
			   QueryParser qp = new QueryParser("title",analyzer);
			   query = qp.parse(keyword);
			   Term term = new Term("content",keyword);
			   FuzzyQuery fq = new FuzzyQuery(term);
			   Date start = new Date();
			   Hits hits = searcher.search(query);
			   SimpleHTMLFormatter simpleHTMLFormatter = new SimpleHTMLFormatter("<read>","</read>");   
			   highlighter = new Highlighter(simpleHTMLFormatter,new QueryScorer(query));      
			   highlighter.setTextFragmenter(new SimpleFragmenter(10));
			   Date end = new Date();
			   return hits;
		  }catch(Exception e){
		   e.printStackTrace();
		   return null;
		  }
		 }
		 
		 public String exportResult(Hits h){
			 String result = null;
			  if(h.length() == 0){
			   System.out.println("δ���ֽ��.");
			   result = "δ���ֽ��.";
			  }else{
			   for(int i = 0; i < h.length(); i++){
			    try{
			     Document doc = h.doc(i);
			     result = result + doc.get("content");
			     TokenStream tokenStream =
			    	 analyzer.tokenStream("content", new StringReader(doc.get("title")));
			    }catch(Exception e){
			     e.printStackTrace();
			    }
			   }
			  }
			  System.out.println("--------------------------------------");
			 }
		 	return result;
			}
	
		 public void printResult(Hits h){
		  if(h.length() == 0){
		   System.out.println("δ���ֽ��.");
		  }else{
		   for(int i = 0; i < h.length(); i++){
		    try{
		     Document doc = h.doc(i);
		     TokenStream tokenStream =analyzer.tokenStream("content", new StringReader(doc.get("title")));
		    }catch(Exception e){
		     e.printStackTrace();
		    }
		   }
		  }
		  System.out.println("--------------------------------------");
		 }
		}
}
